from django.shortcuts import render,redirect
from .models import Book

def book_list(request):
    books = Book.objects.all()
    return render(request, 'book_list.html',{'books': books})

def book_add(request):
    if request.method == 'POST':
        title = request.POST['title']
        author = request.POST['author']
        publish_date = request.POST['publish_date']
        description = request.POST['description']

        Book.objects.create(
            title=title,
            author=author,
            publish_date=publish_date,
            description=description
        )
        return redirect('book_list')

    return render(request, 'book_add.html')

def book_detail(request, id):
    book = Book.objects.get(id=id)  
    return render(request, 'book_detail.html', {'book': book})

def book_update(request, id):
    book = Book.objects.get(id=id)

    if request.method == 'POST':
        book.title = request.POST['title']
        book.author = request.POST['author']
        book.publish_date = request.POST['publish_date']
        book.description = request.POST['description']
        book.save()
        return redirect('book_list')

    return render(request, 'book_form.html', {'book': book})


def book_delete(request, id):
    book = Book.objects.get(id=id)
    book.delete()
    return redirect('book_list')