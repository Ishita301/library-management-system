
from django.contrib import admin
from django.urls import path
from library import views  

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.book_list, name='book_list'),
    path('add/', views.book_add, name='book_add'),
    path('delete/<int:id>/', views.book_delete, name='book_delete'),
    path('detail/<int:id>/', views.book_detail, name='book_detail'),
    path('edit/<int:id>/', views.book_update, name='book_update'),


]